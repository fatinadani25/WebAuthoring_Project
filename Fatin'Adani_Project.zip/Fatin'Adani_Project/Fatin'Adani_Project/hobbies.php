<?php 
	include("header.php");
?>
         <div id="main">
            <div>
               <h2>Home</h2>
               <hr/>
            </div>
            <div>
			  <img src="image/dancing.jpg"/>
			  </div>
			
			    <p>Well, I have several hobbies. To be honest, I didn't know i had hobbies until i learned and found myself.
				   I love to dance(i was once a dancer back then when i was in primary school, I joined Malay dance and Dance sports CCA
				   which they taught us latin dance,cha cha,waltz,jive and many more!) </p>

				<p>I love to cook too! I love to cook for my loved ones.
				   I cooked lots of dishes but my favourite dish to cook is Salted Egg Cabonara.
				   I love to eat too honestly! I don't know if it's able to be included here but 
				   sometimes or most of the time i finish eating, i'll end up eating it instead.</p>
			</div>
        </div>		  
<?php 
	include("footer.php");
?>
