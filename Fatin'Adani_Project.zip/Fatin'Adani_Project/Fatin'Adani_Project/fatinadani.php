<?php 
	include("header.php");
?>
         <div id="main">
            <div>
               <h2>Home</h2>
               <hr/>
            </div>
            <div>
               <p>Hi, My name is Fatin 'Adani Bte Othman. I will be turning 17 on 25 August this year.
			   I am from Compassvale Secondary School, I had bittersweet memories there but my secondary school life still sucks.
			   I chose ITE COLLEGE WEST because i want to start a new life and meet new people in the west.
			   Eventhough I planned to get in Travel & Tourism, I really hope that i could cope in this course and proceed to Polytechnic
			   and join a course related to my career.</p>
			   
			   <p>I'm blessed to meet a bunch of great people in QU1701B! such as Musliha,Laura,Jiayi,Ainul,Nicholas,Danial and the rest! I felt so glad meeting new people and start a new life here in ITE COLLEGE WEST.
			   These people made me feel wanted and needed, Always there for me when I need them. Hope to create great memories here.
			   Furthermore, hope to stay in contact after we are no loner in the same school or class.</p>
			   
			   <p>My favourite food is anything and everything that is related to cheese or salted egg. 
			    I love cooking salted egg yolk dishes such as salted egg cabonara! I'll save this for later on hobbies section.</p>
			   </div>
		 </div>
             <div id="slidebar">
               		<div>
                    	<fieldset>
                            <legend>
        
                            </legend>
                        </fieldset>
                    </div>                            
			<div>
				  <div id="myCarousel" class="carousel slide"
			   		 data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
						<li data-target="#myCarousel" data-slide-to="1"></li>
						<li data-target="#myCarousel" data-slide-to="2"></li>
                        <li data-target="#myCarousel" data-slide-to="3"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img src="image/2017-01-21 09.26.36 1.jpg" width="400" height="600" title="geeky glasses" />
						</div>
						<div class="item">
							<img src="image/Snapchat-1035591231.jpg" width="400" height="600" title="Farrah"/>
						</div>
						<div class="item">
							<img src="image/Snapchat-1802627828.jpg" width="400" height="600" title="Syaf" />
					    </div>
						<div class="item">
							<img src="image/IMG_20170107_110226_837.jpg" width="400" height="600" title="Photoshoot" />
						</div>
					</div>
					<a href="#myCarousel" data-slide="prev" 
					class="carousel-control left">
						<span class="glyphicon glyphicon-chevron-left">
						</span>
					</a>
					<a href="#myCarousel" data-slide="next" 
					class="carousel-control right">
						<span class="glyphicon glyphicon-chevron-right">
						</span>
					</a>
			   </div>
            </div>
         </div>
		 
		 
		  
<?php 
	include("footer.php");
?>

