		<div id="footer">
            &copy;Fatin Adani's&nbsp;&nbsp;&nbsp;
         </div>
   </body>
</html>
