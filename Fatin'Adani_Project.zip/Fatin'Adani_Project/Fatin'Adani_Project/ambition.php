<?php 
	include("header.php");
?>
         <div id="main">
            <div>
               <h2>Home</h2>
               <hr/>
            </div>
			
            <div>
			<div id="myCarousel" class="carousel slide"
			   		 data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
						<li data-target="#myCarousel" data-slide-to="1"></li>
						<li data-target="#myCarousel" data-slide-to="2"></li>
                        <li data-target="#myCarousel" data-slide-to="3"></li>
					</ol>
			<div class="carousel-inner">
						<div class="item active">
							<img src="image/Stewardess.jpg" width="400" height="600" title="SIA Stewardess" />
						</div>
						<div class="item">
							<img src="image/MissSingapore.jpg" width="400" height="600" title="Miss Singapore"/>
							</div>
						<div class="item">
							<img src="image/MissUniverse2017.jpg" width="400" height="600" title="Miss Universe" />
						</div>
					</div>
					<a href="#myCarousel" data-slide="prev" 
					class="carousel-control left">
						<span class="glyphicon glyphicon-chevron-left">
						</span>
					</a>
					<a href="#myCarousel" data-slide="next" 
					class="carousel-control right">
						<span class="glyphicon glyphicon-chevron-right">
						</span>
					</a>
			   </div>
            </div>
         </div>
			    
				<p>My ambition is to be a full time stewardess working under SIA (Singapore Airlines) and a part time
				model. Since young I always wanted to travel the world and fans. </p>
				
				<p>Besides, I always wanted to be participate in Miss Singapore and hope that i would be able to represent Singapore
				to Miss Universe. I want to make Singapore proud one day because Singapore never won in Miss Universe but 
				it will be delusional if i will be able to be crown as Miss Universe. </p>
				
				<p>As for stewardess, I always thought that it will be fun to travel the world and also serve people's needs and wants in the
				airpline espicially in SIA. SIA is a very strict company and all the cabin crews are well-mannered. I hope that i'm capable 
				of what i'm planning to do in future.</p>
				
				<p>My future is in my hands, i'll do my very best to make it happen.</p>
				
<?php 
	include("footer.php");
?>			