<?php 
	include("header.php");
?>
         <div id="main">
			<div>
			<img src="image/Othman's.jpg"/>	
				
				<p>Here's a little introduction of The Othman Family which consist of a King, a Queen and two princess.
				I am the youngest child and I have an elder sister who is 21 this year named Kamilia in pursuing Hospitality in College West. 
				She's about to end her ITE life in a weeks in March 2017 and continue her studies in a Polytechnic. </p>
				
				<p>Next is the Queen which is my beloved mother, she's working as a cleaner and she helps my dad to pay for whatever that my sister and i wanted and needed
				since the day she started working in 2013. She was a housewife when I was younger and decided to start working when I was in Secondary 1.
				She's a great mum who's able to make time for her work and our family. She's able to do multi-task all at once,
				I'm so blessed to have her in my life.</p>
				
				<p>Like what they said, "Keep the last for the best". This is my one and only King which is my father, He is the most hardworking and kind-hearted man I ever met.
				He is someone that i actually need and want in the future. He is a very patient man who always motivate me to do better in life. He never stop supporting me eventhough most 
				of the time i tend to fall and breakdown. I always wanted to be like him but he is an introvert to likes to be alone most of the time.
				He tends to do his stuff by his own, he taught me how to be such an independent person.</p>