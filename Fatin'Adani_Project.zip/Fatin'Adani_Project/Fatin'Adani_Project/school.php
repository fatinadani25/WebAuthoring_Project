<?php 
	include("header.php");
?>

    <p>I used to be in Egdefield Primary School (Batch 2007 to 2012) and Compassvale Secondary School (Batch 2013 to 2016). </p>
	
	<?php 
	include("footer.php");
?>