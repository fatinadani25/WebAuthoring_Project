<!doctype html>
<html>
   <head>
      <!-- Stylesheet for my website:) -->
	  <link rel="stylesheet" href="css/bootstrap.min.css"/>
	  <script src="js/jquery.min.js"></script>
	  <script src="js/bootstrap.min.js"></script>
      <link rel="stylesheet" href="css/mystyle.css"/>
      <title>Fatin Adani's</title>
   </head>
   <body>
      <div id="wrap">
         <div id="banner">
            <img src="image/2017-01-02 05.08.37 1.jpg" title="Me" width="1099" height="405"/>
         </div>
         <div id="nav">
            <nav role="navigation" class="navbar navbar-default">
				<div class="navbar-header">
					<button type="button" data-target="#navbarCollapse"
					data-toggle="collapse" class="navbar-toggle">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<div class="visible-xs">
						<a class="navbar-brand" href="index.html">Fatin Adani's</a>
					</div>
				</div>
				
				<div id="navbarCollapse" class="collapse navbar-collapse">
					<ul class="nav navbar-nav">
						<li><a href="fatinadani.php">Me</a></li>
						<li class="dropdown">
							<a data-toggle="dropdown" 
							class="dropdown-toggle" href="#">
							My Interests <div class="caret"></div>
							</a>
							<ul role="menu" class="dropdown-menu">
								<li><a href="ambition.php">Ambition</a></li>
								<li><a href="hobbies.php">Hobbies</a></li>
							</ul>
						</li>
						<li><a href="school.php">School Life</a></li>						
						<li><a href="family.php">Family</a></li>
					</ul>
				</div>
		   </nav>
         </div>